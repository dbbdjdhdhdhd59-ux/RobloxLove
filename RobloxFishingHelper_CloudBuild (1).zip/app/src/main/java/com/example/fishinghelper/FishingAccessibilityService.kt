package com.example.fishinghelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FishingAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_START = "com.example.fishinghelper.START"
        const val ACTION_STOP = "com.example.fishinghelper.STOP"
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_START -> startLoop()
                ACTION_STOP -> stopLoop()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter().apply {
            addAction(ACTION_START)
            addAction(ACTION_STOP)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
        receiverRegistered = true
    }

    private fun startLoop() {
        if (running) return
        running = true
        castThenClick()
    }

    private fun stopLoop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun castThenClick() {
        if (!running) return
        val p = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val holdMs = p.getInt("hold", 800).coerceIn(100, 5000).toLong()
        val waitMs = p.getInt("wait", 5000).coerceIn(0, 60000).toLong()
        val intervalMs = p.getInt("interval", 120).coerceIn(80, 2000).toLong()
        val x = p.getInt("x", 540).toFloat()
        val y = p.getInt("y", 1200).toFloat()

        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, holdMs))
            .build()

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (!running) return
                handler.postDelayed({ clickRepeatedly(x, y, intervalMs) }, waitMs)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (running) handler.postDelayed({ castThenClick() }, 1000)
            }
        }, handler)
        if (!dispatched) handler.postDelayed({ if (running) castThenClick() }, 1000)
    }

    private fun clickRepeatedly(x: Float, y: Float, intervalMs: Long) {
        if (!running) return
        val path = Path().apply { moveTo(x, y) }
        val tap = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(tap, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (running) handler.postDelayed({ clickRepeatedly(x, y, intervalMs) }, intervalMs)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (running) handler.postDelayed({ clickRepeatedly(x, y, intervalMs) }, intervalMs)
            }
        }, handler)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopLoop() }

    override fun onDestroy() {
        stopLoop()
        if (receiverRegistered) unregisterReceiver(receiver)
        super.onDestroy()
    }
}
