package com.example.fishinghelper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var hold: EditText
    private lateinit var wait: EditText
    private lateinit var interval: EditText
    private lateinit var x: EditText
    private lateinit var y: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }

        fun label(text: String) {
            root.addView(TextView(this).apply { this.text = text; textSize = 15f; setPadding(0, 10, 0, 3) })
        }
        fun field(title: String, key: String, default: String): EditText {
            label(title)
            return EditText(this).apply {
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(prefs.getString(key, default))
                root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }

        root.addView(TextView(this).apply {
            text = "Помощник рыбалки Roblox"
            textSize = 23f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Сначала включи службу специальных возможностей. Координаты X/Y — точка на экране Roblox, куда игра принимает нажатия."
            textSize = 14f
            setPadding(0, 12, 0, 8)
        })

        hold = field("Длительность удержания для заброса (мс)", "hold", "800")
        wait = field("Ожидание после заброса (мс)", "wait", "5000")
        interval = field("Интервал между кликами (мс, минимум 80)", "interval", "120")
        x = field("Координата X на экране", "x", "540")
        y = field("Координата Y на экране", "y", "1200")

        fun save() {
            fun number(e: EditText, fallback: Int) = e.text.toString().toIntOrNull() ?: fallback
            prefs.edit()
                .putInt("hold", number(hold, 800).coerceIn(100, 5000))
                .putInt("wait", number(wait, 5000).coerceIn(0, 60000))
                .putInt("interval", number(interval, 120).coerceIn(80, 2000))
                .putInt("x", number(x, 540).coerceAtLeast(0))
                .putInt("y", number(y, 1200).coerceAtLeast(0))
                .apply()
        }

        root.addView(Button(this).apply {
            text = "Открыть настройки специальных возможностей"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "Сохранить настройки"
            setOnClickListener { save(); Toast.makeText(this@MainActivity, "Настройки сохранены", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply {
            text = "СТАРТ — затем переключись в Roblox"
            setOnClickListener {
                save()
                sendBroadcast(Intent(FishingAccessibilityService.ACTION_START).setPackage(packageName))
                Toast.makeText(this@MainActivity, "Команда старта отправлена. Переключись в Roblox.", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(Button(this).apply {
            text = "СТОП"
            setOnClickListener {
                sendBroadcast(Intent(FishingAccessibilityService.ACTION_STOP).setPackage(packageName))
                Toast.makeText(this@MainActivity, "Остановка отправлена", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(root)
    }
}
